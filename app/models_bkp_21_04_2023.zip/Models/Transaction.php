<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;
    protected $fillable = [
        'company_id',
		'company_to_id',
        'branch_id',
        'brand_id',
        'transaction_type',
        'qty',
        'log',
        'created_by'
    ];
}
